#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(void){
    state();
    exit();
}